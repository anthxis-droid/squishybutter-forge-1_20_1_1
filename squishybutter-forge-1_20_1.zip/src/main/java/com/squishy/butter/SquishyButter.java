package com.squishy.butter;

import java.util.EnumMap;
import java.util.Map;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(SquishyButter.MODID)
public class SquishyButter {
    public static final String MODID = "squishybutter";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<ButterType, RegistryObject<Block>> BUTTER_BLOCKS = new EnumMap<>(ButterType.class);
    public static final Map<ButterType, RegistryObject<Item>> BUTTER_ITEMS = new EnumMap<>(ButterType.class);

    static {
        for (ButterType type : ButterType.values()) {
            RegistryObject<Block> block = BLOCKS.register(type.id, () -> new SquishyButterBlock(type));
            BUTTER_BLOCKS.put(type, block);
            BUTTER_ITEMS.put(type, ITEMS.register(type.id,
                    () -> new SquishyButterItem(block.get(), new Item.Properties().stacksTo(16))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("squishy_butter", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.squishybutter"))
                    .icon(() -> new ItemStack(BUTTER_ITEMS.get(ButterType.GOLD).get()))
                    .displayItems((params, output) -> BUTTER_ITEMS.values().forEach(i -> output.accept(i.get())))
                    .build());

    public SquishyButter() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
