package com.squishy.butter;

import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.VoxelShape;

public enum ButterType {
    BATMAN("batman", new double[]{0, 0, 6, 16, 4, 10}),
    COCACOLA("cocacola", new double[]{0, 0, 6, 16, 4, 10}),
    WATERMELON("watermelon", new double[]{0, 0, 6, 16, 4, 10}),
    GLITTER("glitter", new double[]{0, 0, 6, 16, 4, 10}),
    GOLD("gold", new double[]{0, 0, 6, 16, 4, 10}),
    REDBULL("redbull", new double[]{0, 0, 5, 16, 4, 11}),
    BMW("bmw", new double[]{0, 0, 6, 16, 4, 10});

    public final String id;
    private final VoxelShape[] shapes = new VoxelShape[4]; // index = Direction#get2DDataValue (S,W,N,E)

    ButterType(String id, double[] b) {
        this.id = id;
        for (int t = 0; t < 4; t++) {
            double x0 = b[0] - 8, z0 = b[2] - 8, x1 = b[3] - 8, z1 = b[5] - 8;
            for (int i = 0; i < t; i++) { // rotate 90 deg clockwise seen from above, like blockstate "y"
                double nx0 = -z1, nx1 = -z0, nz0 = x0, nz1 = x1;
                x0 = nx0; x1 = nx1; z0 = nz0; z1 = nz1;
            }
            shapes[t] = Block.box(x0 + 8, b[1], z0 + 8, x1 + 8, b[4], z1 + 8);
        }
    }

    public VoxelShape shape(Direction facing) {
        return shapes[facing.get2DDataValue()];
    }
}
