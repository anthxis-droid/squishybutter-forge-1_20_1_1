SQUISHY BUTTER - Minecraft 1.20.1 / Forge 47.x

JAR NASIL YAPILIR
1) Java 17 kur (JDK 17).
2) https://files.minecraftforge.net adresinden 1.20.1 icin Forge MDK indir (47.3.0 veya ustu), zipten cikar.
3) Bu klasordeki "src" klasorunu MDK'daki "src" ile DEGISTIR.
   (MDK'nin kendi build.gradle'i kalsin; sadece mods.toml ve java dosyalari bizimkiler olsun.
    MDK'daki gradle.properties icinde mod_id=squishybutter yap.)
   VEYA bu klasoru oldugu gibi kullanip, icine MDK'dan gradlew, gradlew.bat ve gradle/ klasorunu kopyala.
4) Terminalde:  gradlew build
5) Jar: build/libs/squishybutter-1.0.0.jar  -> mods klasorune at.

OYUNDA
- Yaraticilik sekmesi: "Squishy Butter".
- Havaya sag tik = squish sesi. Bir bloga sag tik = yere koyar.
- Yerdeki butter'a sag tik = squish. Kirinca kendini birakir.
- 7 model: Batman, Coca-Cola, Karpuz, Glitter, Altin, Red Bull, BMW.
